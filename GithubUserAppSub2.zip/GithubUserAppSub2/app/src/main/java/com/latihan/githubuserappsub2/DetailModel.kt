package com.latihan.githubuserappsub2

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.latihan.githubuserappsub2.retrofit.ApiConfig
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.onCompletion
import kotlinx.coroutines.flow.onStart
import kotlinx.coroutines.launch

class DetailModel : ViewModel() {
    val resultDetailUser = MutableLiveData<UtilsData>()
    val resultFollowersUser = MutableLiveData<UtilsData>()
    val resultFollowingUser = MutableLiveData<UtilsData>()

    fun getDetailUser(username: String) {
        viewModelScope.launch {
            flow {
                val response = ApiConfig
                    .apiService
                    .getDetailUsers(username)

                emit(response)
            }.onStart {
                resultDetailUser.value = UtilsData.Loading(true)
            }.onCompletion {
                resultDetailUser.value = UtilsData.Loading(false)
            }.catch {
                it.printStackTrace()
                resultDetailUser.value = UtilsData.Error(it)
            }.collect {
                resultDetailUser.value = UtilsData.Success(it)
            }
        }
    }

    fun getFollowers(username: String) {
        viewModelScope.launch {
            flow {
                val response = ApiConfig
                    .apiService
                    .getFollowersUsers(username)

                emit(response)
            }.onStart {
                resultFollowersUser.value = UtilsData.Loading(true)
            }.onCompletion {
                resultFollowersUser.value = UtilsData.Loading(false)
            }.catch {
                it.printStackTrace()
                resultFollowersUser.value = UtilsData.Error(it)
            }.collect {
                resultFollowersUser.value = UtilsData.Success(it)
            }
        }
    }

    fun getFollowing(username: String) {
        viewModelScope.launch {
            flow {
                val response = ApiConfig
                    .apiService
                    .getFollowingUsers(username)

                emit(response)
            }.onStart {
                resultFollowingUser.value = UtilsData.Loading(true)
            }.onCompletion {
                resultFollowingUser.value = UtilsData.Loading(false)
            }.catch {
                it.printStackTrace()
                resultFollowingUser.value = UtilsData.Error(it)
            }.collect {
                resultFollowingUser.value = UtilsData.Success(it)
            }
        }
    }
}