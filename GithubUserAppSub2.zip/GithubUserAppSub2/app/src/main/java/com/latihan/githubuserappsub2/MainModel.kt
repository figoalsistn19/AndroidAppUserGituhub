package com.latihan.githubuserappsub2

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.latihan.githubuserappsub2.retrofit.ApiConfig
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.onCompletion
import kotlinx.coroutines.flow.onStart
import kotlinx.coroutines.launch

class MainModel : ViewModel() {
    val resultDetailUser = MutableLiveData<UtilsData>()

    fun getUser() {
        viewModelScope.launch {
            flow {
                val response = ApiConfig
                    .apiService
                    .getUsers()

                emit(response)
            }.onStart {
                resultDetailUser.value = UtilsData.Loading(true)
            }.onCompletion {
                resultDetailUser.value = UtilsData.Loading(false)
            }.catch {
                it.printStackTrace()
                resultDetailUser.value = UtilsData.Error(it)
            }.collect {
                resultDetailUser.value = UtilsData.Success(it)
            }
        }
    }
}
