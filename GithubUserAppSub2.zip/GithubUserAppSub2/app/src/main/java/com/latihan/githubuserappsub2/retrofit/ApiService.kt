package com.latihan.githubuserappsub2.retrofit

import retrofit2.http.GET
import retrofit2.http.Path

interface ApiService {
    @JvmSuppressWildcards
    @GET("users")
    suspend fun getUsers(): MutableList<UserResponse.Item>

    @JvmSuppressWildcards
    @GET("users/{username}")
    suspend fun getDetailUsers(@Path("username") username: String): DetailUserResponse

    @JvmSuppressWildcards
    @GET("/users/{username}/followers")
    suspend fun getFollowersUsers(@Path("username") username: String): MutableList<UserResponse.Item>

    @JvmSuppressWildcards
    @GET("/users/{username}/following")
    suspend fun getFollowingUsers(@Path("username") username: String): MutableList<UserResponse.Item>
}