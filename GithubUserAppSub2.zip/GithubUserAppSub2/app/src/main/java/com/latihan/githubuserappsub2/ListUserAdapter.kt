package com.latihan.githubuserappsub2

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.latihan.githubuserappsub2.databinding.ItemRowUserBinding
import com.latihan.githubuserappsub2.retrofit.UserResponse


class ListUserAdapter(
    private val data: MutableList<UserResponse.Item> = mutableListOf(),
    private val listener: (UserResponse.Item) -> Unit
) :
    RecyclerView.Adapter<ListUserAdapter.UserViewHolder>() {

    @SuppressLint("NotifyDataSetChanged")
    fun setDataUser(data: MutableList<UserResponse.Item>) {
        this.data.clear()
        this.data.addAll(data)
        notifyDataSetChanged()
    }

    class UserViewHolder(private val listUser: ItemRowUserBinding) : RecyclerView.ViewHolder(listUser.root) {
        fun binding(item: UserResponse.Item) {
            listUser.imgItemPhoto.load(item.avatar_url)
            listUser.tvItemUsername.text = item.login
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UserViewHolder =
        UserViewHolder(
            ItemRowUserBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )

    override fun onBindViewHolder(holder: UserViewHolder, position: Int) {
        val item = data[position]
        holder.binding(item)
        holder.itemView.setOnClickListener { listener(item) }
    }

    override fun getItemCount(): Int = data.size

}