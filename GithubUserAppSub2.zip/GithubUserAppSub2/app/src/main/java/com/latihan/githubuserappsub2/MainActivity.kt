package com.latihan.githubuserappsub2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.activity.viewModels
import androidx.core.view.isVisible
import androidx.recyclerview.widget.LinearLayoutManager
import com.latihan.githubuserappsub2.databinding.ActivityMainBinding
import com.latihan.githubuserappsub2.retrofit.UserResponse


class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val adapter: ListUserAdapter by lazy {
        ListUserAdapter { user ->
            Intent(this, DetailUserActivity::class.java).apply {
                putExtra("username", user.login)
                startActivity(this)
            }
        }
    }

    private val viewModel by viewModels<MainModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.rvUsers.layoutManager = LinearLayoutManager(this)
        binding.rvUsers.setHasFixedSize(true)
        binding.rvUsers.adapter = adapter

        viewModel.resultDetailUser.observe(this) {
            when (it) {
                is UtilsData.Success<*> -> {
                    adapter.setDataUser(it.data as MutableList<UserResponse.Item>)
                }
                is UtilsData.Error -> {
                    Toast.makeText(this, it.exception.message.toString(), Toast.LENGTH_SHORT).show()
                }
                is UtilsData.Loading -> {
                    binding.progressBar.isVisible = it.isLoading
                }
            }
        }

        viewModel.getUser()

    }
}
